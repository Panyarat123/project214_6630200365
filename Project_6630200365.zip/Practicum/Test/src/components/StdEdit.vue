<template>
    <div class="card">
          <div class="card-body">
              <h5 class="text-primary">แก้ไขข้อมูลนิสิต</h5>
              <form @submit.prevent="handleSubmit()">
                  <div class="row">
      <!-- <div class="col-lg-4 col-md-4 col-sm-6 mt-2">
          <label for="subId" class="form-label">รหัสนิสิต</label>
          <input type="text" id="subId" class="form-control" v-model.trim="stds.id" required />
      </div>
      <div class="col-lg-8 col-md-8 col-sm-6 mt-2">
          <label for="stdName" class="form-label">ชื่อ นามสกุล</label>
          <input type="text" id="stdName" class="form-control" v-model.trim="stds.name" required />
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
          <label for="" class="form-label">สาขา</label>
          <div class="form-check">
              <input class="form-check-input" type="radio" id="stdMajor" value="CS" v-model="stds.major" />
              <label class="form-check-label" for="stdMajor">Computer Science</label>
          </div>
          <div class="form-check">
              <input class="form-check-input" type="radio" id="stdMajor" value="DT" v-model="stds.major" />
              <label class="form-check-label" for="stdMajor">Digital Technology</label>
          </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-3 mt-2">
          <label for="stdYr" class="form-label">ชั้นปี</label>
          <select id="stdYr" class="form-select" v-model="stds.yr">
              <option value="1">ปี1</option>
              <option value="2">ปี2</option>
              <option value="3">ปี3</option>
              <option value="4">ปี4</option>
              <option value="5">เกินปี4</option>
          </select>
      </div> -->
      <div class="col-2 mt-4 d-flex align-items-center">
          <button id="btnSubmit" type="submit" class="btn btn-primary ">บันทึก</button>
      </div>
  </div>
  
              </form>
  
          </div>
      </div>
      <div class="alert alert-success mt-2" v-show="editSuccess">
          แก้ไขข้อมูล {{ stds.id }} - {{ stds.name }} สำเร็จ
      </div>
      <div class="alert alert-success mt-2" v-show="editError">
          {{ errMessage }}
      </div>
  </template>
  
  <script>
  export default {
      name:'StdEdit',
      props:['stdId'],
      data(){
          return{
              stds:[],
              editSuccess:false,
              editError:false,
              errMessage:'',
              
          }
      },
      mounted() {
      fetch('http://localhost:3000/Extra_information/' + 123456)
          .then(res => res.json())
          .then(data => this.stds = data)
          .catch(err => console.log(err.message))
      },
      methods:{
              handleSubmit() {
              //สร้าง Object เพื่อเตรียมส่งข้อมูล - ค่า properties ที่ v-model กับ form ไว้
              let students = {
                  id: this.stds.id,
                  name: this.stds.name,
                  major: this.stds.major,
                  yr: this.stds.yr
              }
              //กำหนดการติดต่อกับ endpoint ระบุ Method POST
              fetch('http://localhost:3000/Extra_information/' + 123456, {
                  method: 'PATCH',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(students)
              })
                  .then(() => {
                      this.editSuccess = true
                  })
                  .catch((err) => {
                      this.editError = true
                      this.editMessage = err
                  })
          }
      }
  
  
  }
  </script>
  
  <style>
  
  </style>