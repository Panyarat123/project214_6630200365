<template>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                เพิ่มข้อมูลวิชา
            </div>
            <div class="card-body">
                <form @submit.prevent="handleSubmit">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="stdId">รหัสวิชา</label>
                                <input type="text" id="stdId" class="form-control" v-model.trim="stds.id" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="stdName_en">ชื่อวิชา (EN)</label>
                                <input type="text" id="stdName_en" class="form-control" v-model.trim="stds.name_En_suB" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="stdName_th">ชื่อวิชา (TH)</label>
                                <input type="text" id="stdName_th" class="form-control" v-model.trim="stds.name_Th_suB" required>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6">
                            <div class="form-group">
                                <label for="stdcredit">หน่วยกิต</label>
                                <select id="stdcredit" class="form-select" v-model="stds.Credit">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6">
                            <div class="form-group">
                                <label for="stdgr">เกรด</label>
                                <select id="stdgr" class="form-select" v-model="stds.Grade">
                                    <option value="A">A</option>
                                    <option value="B+">B+</option>
                                    <option value="B">B</option>
                                    <option value="C+">C+</option>
                                    <option value="C">C</option>
                                    <option value="D+">D+</option>
                                    <option value="D">D</option>
                                    <option value="F">F</option>
                                    <option value="W">W</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6">
                            <div class="form-group">
                                <label for="stdYr">ชั้นปี</label>
                                <select id="stdYr" class="form-select" v-model="stds.Year_for_std">
                                    <option value="1">ปี1</option>
                                    <option value="2">ปี2</option>
                                    <option value="3">ปี3</option>
                                    <option value="4">ปี4</option>
                                    <option value="5">เกินปี4</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6">
                            <div class="form-group">
                                <label for="stdsem">เทอม</label>
                                <select id="stdsem" class="form-select" v-model="stds.Term">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">SUMMER</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <button type="submit" class="btn btn-primary">
                                บันทึก
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="alert alert-success mt-2" v-if="addSuccess">
            บันทึกข้อมูล {{ stds.id }} - {{ stds.name_En_suB }}
        </div>
    </div>
</template>

<script>
export default {
    name: 'StdAdd',
    data() {
        return {
            stds: {
                id: "",
                name_En_suB: "",
                name_Th_suB: "",
                Credit: "",
                Grade: "",
                Year_for_std: "",
                Term: ""
            },
            addSuccess: false
        }
    },
    methods: {
        handleSubmit() {
            let students = {
                id: this.stds.id,
                name_En_suB: this.stds.name_En_suB,
                name_Th_suB: this.stds.name_Th_suB,
                Credit: this.stds.Credit,
                Grade: this.stds.Grade,
                Year_for_std:this.stds.Year_for_std,
                Term: this.stds.Term
            }
            fetch('http://localhost:3000/Extra_information', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(students)
            })
                .then(() => {
                    this.addSuccess = true
                })
                .catch((err) => {
                    console.error(err);
                })
        }
    }
}
</script>

<style scoped>
.container {
    max-width: 800px;
    margin: auto;
}

.card-header {
    font-size: 1.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.alert {
    margin-top: 1.5rem;
}
</style>
