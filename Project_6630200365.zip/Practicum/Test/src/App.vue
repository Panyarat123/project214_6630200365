<template>
 

  <div class="container">
    <div class="content">
      

      <h1 class="mt-3 text-dark"> Portfolio </h1>
      <img src="./assets/image1.jpg" alt="image1" class="img-fluid mt-3">
      <h4 class="mt-3 text-dark">{{ name_En }}</h4>
      <h4 class="text-dark">{{ name_Th }}</h4>
      <h4 class="text-dark">ประวัติ : {{ History }}</h4>
      

    
      <div class="m-2" v-if="showaddsub">
        <addsub ref="" />
      </div>

      <!-- <div class="m-2" v-if="showDetail_sub">
          <Detail_sub />
        </div> -->


      
      <h4 class="mt-3 text-dark">สาขา : Computer Science</h4>
      <h4 class="mt-3 text-dark">ชั้นปี : 2</h4>
      <h4 class="mt-3 text-dark">อายุ : 20</h4>
      <h4 class="text-dark">รหัสนิสิต : {{ id }}</h4>
      <h4 class="text-dark">งานอดิเรก : {{ Hobby }}</h4>
      <h4 class="mt-3 text-dark">อีเมล : : panyarat.n@ku.th</h4>
      <h4 class="mt-3 text-dark">เบอร์โทร : {{ Phone_number }}</h4>

      <button class="btn btn-dark" @click="toggleList()">เปิด/ปิดการดูเกรด</button>
      <span class="mx-2"></span>
      <button class="btn btn-dark" @click="toggleAdd()">เพิ่มข้อมูล</button>


      <div class="m-2" v-if="showAdd_sub">
        <Add_sub />
      </div>

      <div class="m-2" v-if="showDetail_sub">
        <Detail_sub @delete="reload()" />
      </div>

    </div>
  </div>


</template>

<script>
import Add_sub from './components/Add_sub.vue';
import Detail_sub from './components/Detail_sub.vue';

export default {
  name: 'App',
  components: {
    Detail_sub, Add_sub
  },
  data() {
    return {
   
      id: "6630200365",
      name_En: "Panyarat Netrune",
      name_Th: "ปัญญรัช เนตรรื่น",
      major: "CS",
      Age: "20",
      History: "โรงเรียนสมัยมัธยม : โรงเรียนเทศบาลวัดราษฎ์นิยมธรรม",
      Hobby: "ฟังเพลง เล่นเกม",
      Phone_number: "093-149-2997",
      Email: "panyarat.n@ku.th",
      showDetail_sub: true,
      showAdd_sub: false
    }
  },
  methods: {
    toggleList() {
      this.showDetail_sub = !this.showDetail_sub
      this.showAdd_sub = false
    },
    toggleAdd() {
      this.showAdd_sub = !this.showAdd_sub
      this.showDetail_sub = false
    },
    reload() {
      this.showDetail_sub = !this.showDetail_sub
    }
  }

}
</script>

<style>

/* Navbar */
.navbar {
  background-color: #4800ff; /* เปลี่ยนสีพื้นหลังของ Navbar */
}

.navbar-brand {
  font-size: 1.5rem; /* ปรับขนาดตัวหนังสือของ Navbar Brand */
}

.navbar-toggler {
  border-color: rgba(17, 116, 214, 0.5); /* เปลี่ยนสีเส้นขอบของปุ่ม Toggle Navbar */
}

.navbar-toggler-icon {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cpath stroke='rgba%2812555,255,255,.5%29' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e"); /* เปลี่ยนสีไอคอน Navbar Toggler */
}

/* Content */
.content {
  margin-top: 20px; /* ปรับระยะขอบบนของเนื้อหา */
}

.text-primary {
  color: #00ff44; /* เปลี่ยนสีข้อความ Primary */
}

.text-dark {
  color: #486bf8; /* เปลี่ยนสีข้อความ Blue 100 */
}

.text-opacity-50 {
  opacity: 0.5; /* ปรับค่าความทึบของข้อความ */
}

.btn-warning {
  background-color: #0e0a00; /* เปลี่ยนสีปุ่ม Warning */
  border-color: #000000; /* เปลี่ยนสีเส้นขอบปุ่ม Warning */
}

.btn-info {
  background-color: #00ff4c; /* เปลี่ยนสีปุ่ม Info */
  border-color: #00ff04; /* เปลี่ยนสีเส้นขอบปุ่ม Info */
}

.btn-warning,
.btn-info {
  color: #84ff00; /* เปลี่ยนสีของข้อความบนปุ่ม */
}

/* Container */
.container {
  margin: 20px;
  padding: 20px;
  border: 1px solid #ff00bb; /* เพิ่มเส้นขอบ Container */
  border-radius: 10px; /* ปรับรูปร่าง Container เป็นมนตรีวงกลม */
  
}

body, html {
  background-color: #000000;
}

</style>
